#ifndef _VAL_SMDKC110_H
#define _VAL_SMDKC110_H

#include <config.h>
#include <version.h>

#include <s5pc110.h>

#endif

